#pragma once

extern int MOD;

int pnorm(int num);

int padd(int num1, int num2);
int psub(int num1, int num2);
int pmul(int num1, int num2);
int pdiv(int num1, int num2);